<h1>Adicionar</h1>

<form method="POST" action="adicionar_submit.php">
	Nome:<br/>
	<input type="text" name="nome" /><br/><br/>

	E-mail:<br/>
	<input type="email" name="email" /><br/><br/>

	<input type="submit" value="Adicionar" />
</form>